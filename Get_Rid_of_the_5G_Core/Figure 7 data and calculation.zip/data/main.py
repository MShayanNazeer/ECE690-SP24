import matplotlib.pyplot as plt
import os
from collections import defaultdict

# List of file names
file_names = [
    "a01_01_1sec.txt", "a02_01_1sec.txt", "a03_01_1sec.txt", "a03_02_1sec.txt",
    "a04_01_1sec.txt", "a04_02_1sec.txt", "a05_01_1sec.txt", "a05_02_1sec.txt",
    "a06_01_1sec.txt", "a06_02_1sec.txt", "a06_03_1sec.txt", "a06_04_1sec.txt",
    "a06_05_1sec.txt", "a06_06_1sec.txt", "a06_07_1sec.txt", "a06_08_1sec.txt",
    "a06_09_1sec.txt", "b01_01_1sec.txt", "b01_02_1sec.txt", "b01_03_1sec.txt",
    "b01_04_1sec.txt", "b01_05_1sec.txt", "b01_06_1sec.txt", "b01_07_1sec.txt",
    "b02_01_1sec.txt", "b02_02_1sec.txt", "b02_03_1sec.txt", "b02_04_1sec.txt",
    "b02_05_1sec.txt", "c01_01_1sec.txt", "c01_02_1sec.txt", "c01_03_1sec.txt",
    "c01_04_1sec.txt", "c01_05_1sec.txt", "c02_01_1sec.txt", "c03_01_1sec.txt",
    "c03_02_1sec.txt", "c03_03_1sec.txt", "d01_01_1sec.txt", "e01_01_1sec.txt"
]

# Directory where the txt files are located
directory = "/Users/alvin/Downloads/Energy Calculation/cs213b_termproject_bo-jhang_taqi/data"

# Function to read energy values from a file
def read_energy_values(file_path):
    with open(file_path, 'r') as file:
        return [float(line.strip()) for line in file]

# Group files by log identifier
file_groups = defaultdict(list)
for file_name in file_names:
    log_id = file_name.split('_')[0] + '_' + file_name.split('_')[1]
    file_groups[log_id].append(file_name)

# Plot each group of files together
for log_id, files in file_groups.items():
    all_energy_values = []
    
    # Read and concatenate energy values from all files in the group
    for file_name in sorted(files):
        file_path = os.path.join(directory, file_name)
        energy_values = read_energy_values(file_path)
        all_energy_values.extend(energy_values)
    
    # Create a plot
    plt.figure()
    plt.plot(all_energy_values, label=f'Energy (mW) - {log_id}')
    plt.xlabel('Time (s)')
    plt.ylabel('Energy (mW)')
    plt.title(f'Energy over Time for {log_id}')
    plt.legend()
    plt.grid(True)
    
    # Save the plot as a PNG file
    plot_file_name = f'{log_id}_1sec.png'
    plt.savefig(os.path.join(directory, plot_file_name))
    
    # Close the plot to free up memory
    plt.close()

print("Plots created successfully.")
